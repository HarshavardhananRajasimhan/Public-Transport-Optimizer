import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, Tooltip, useMap } from 'react-leaflet';
import L from 'leaflet';
import { Route, TransportMode, VehiclePosition } from '../types';
import { useLiveTransit } from '../hooks/useLiveTransit';
import { MapBusIcon } from './icons/MapBusIcon';
import { MapMetroIcon } from './icons/MapMetroIcon';
import { StartPinIcon } from './icons/StartPinIcon';
import { EndPinIcon } from './icons/EndPinIcon';
import ReactDOMServer from 'react-dom/server';


interface MapDisplayProps {
  route: Route;
  vehiclePositions: VehiclePosition[];
  highlightedSegmentIndex?: number | null;
}

const createDivIcon = (component: React.ReactElement) => {
    return L.divIcon({
        html: ReactDOMServer.renderToString(component),
        className: 'bg-transparent border-0',
        iconSize: [32, 32],
        iconAnchor: [16, 32],
        popupAnchor: [0, -32],
    });
};

const startIcon = createDivIcon(<StartPinIcon />);
const endIcon = createDivIcon(<EndPinIcon />);

const getVehicleIcon = (mode: TransportMode, isLiveGlobal: boolean = false) => {
    const component = mode === TransportMode.BUS 
        ? <MapBusIcon isLive={isLiveGlobal} /> 
        : <MapMetroIcon isLive={isLiveGlobal} />;
    return createDivIcon(component);
};

const segmentColors = {
    [TransportMode.WALK]: '#22c55e', // green-500
    [TransportMode.BUS]: '#ef4444', // red-500
    [TransportMode.METRO]: '#a855f7', // purple-500
    [TransportMode.AUTO_RICKSHAW]: '#f59e0b', // amber-500
};

const MapEffect: React.FC<{
  route: Route;
  highlightedSegmentIndex: number | null | undefined;
}> = ({ route, highlightedSegmentIndex }) => {
  const map = useMap();

  useEffect(() => {
    // Zoom to highlighted segment if it exists and has a path
    if (
      highlightedSegmentIndex !== null &&
      highlightedSegmentIndex !== undefined &&
      route.segments[highlightedSegmentIndex]?.path?.length > 0
    ) {
      const segment = route.segments[highlightedSegmentIndex];
      const bounds = L.latLngBounds(segment.path!.map(p => [p.lat, p.lng]));
      map.flyToBounds(bounds, { padding: [50, 50], duration: 1 });
    } else {
      // Otherwise, zoom to fit the entire route
      const allPaths = route.segments.flatMap(s => s.path || []);
      if (allPaths.length > 1) {
        const bounds = L.latLngBounds(allPaths.map(p => [p.lat, p.lng]));
        map.flyToBounds(bounds, { padding: [50, 50], duration: 1 });
      }
    }
  }, [highlightedSegmentIndex, route, map]);

  return null;
};


export const MapDisplay: React.FC<MapDisplayProps> = ({ route, vehiclePositions, highlightedSegmentIndex }) => {
    const [showLiveTransit, setShowLiveTransit] = useState(true);
    const liveVehicles = useLiveTransit(showLiveTransit);

    const allPaths = route.segments.flatMap(s => s.path || []);

    if (allPaths.length < 2) {
        return <div className="h-80 flex items-center justify-center bg-slate-100 rounded-lg"><p className="text-slate-500">Map data not available for this route.</p></div>;
    }

    const bounds = L.latLngBounds(allPaths.map(p => [p.lat, p.lng]));
    const startPoint = allPaths[0];
    const endPoint = allPaths[allPaths.length - 1];

    return (
        <div>
            <div className="flex justify-end items-center mb-2 px-1">
                <label htmlFor="live-transit-toggle" className="flex items-center cursor-pointer group">
                    <span className="text-sm font-medium text-slate-600 mr-3 group-hover:text-indigo-600 transition">Show Live City Transit</span>
                    <div className="relative">
                        <input
                            type="checkbox"
                            id="live-transit-toggle"
                            className="sr-only peer"
                            checked={showLiveTransit}
                            onChange={() => setShowLiveTransit(!showLiveTransit)}
                        />
                        <div className="w-10 h-6 bg-slate-300 rounded-full peer-checked:bg-indigo-500 transition-colors duration-300"></div>
                        <div className="absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform duration-300 peer-checked:translate-x-full"></div>
                    </div>
                </label>
            </div>

            <MapContainer bounds={bounds} style={{ height: '400px', width: '100%' }} scrollWheelZoom={false} className="z-0">
                <MapEffect route={route} highlightedSegmentIndex={highlightedSegmentIndex} />
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {route.segments.map((segment, index) => {
                    if (segment.path && segment.path.length > 0) {
                        const isHighlighted = index === highlightedSegmentIndex;
                        return <Polyline 
                                    key={index} 
                                    positions={segment.path.map(p => [p.lat, p.lng])} 
                                    color={segmentColors[segment.mode] || 'grey'} 
                                    weight={isHighlighted ? 9 : 5} 
                                    opacity={isHighlighted ? 1.0 : 0.7}
                                />
                    }
                    return null;
                })}

                <Marker position={[startPoint.lat, startPoint.lng]} icon={startIcon}>
                    <Tooltip permanent direction="top" offset={[0, -28]}>Start</Tooltip>
                </Marker>
                <Marker position={[endPoint.lat, endPoint.lng]} icon={endIcon}>
                    <Tooltip permanent direction="top" offset={[0, -28]}>End</Tooltip>
                </Marker>
                
                {vehiclePositions.map(vehicle => (
                    <Marker key={vehicle.id} position={[vehicle.lat, vehicle.lng]} icon={getVehicleIcon(vehicle.mode)}>
                        <Tooltip direction="top" offset={[0, -28]}>
                            Your {vehicle.mode === TransportMode.BUS ? 'Bus' : 'Metro'}
                        </Tooltip>
                    </Marker>
                ))}

                {liveVehicles.map(vehicle => (
                    <Marker key={vehicle.id} position={[vehicle.lat, vehicle.lng]} icon={getVehicleIcon(vehicle.mode, true)}>
                        <Tooltip direction="top" offset={[0, -28]}>
                            Live {vehicle.mode === TransportMode.BUS ? 'Bus' : 'Metro'}
                        </Tooltip>
                    </Marker>
                ))}
            </MapContainer>
        </div>
    );
};